# Current Deployment is Dummy, TO BE CONTINUED...
Microservice 2 using Google App Engine

This will be our second microservice, and we will deploy it to Google App Engine


![google app engine deployment](https://github.com/Lhy121125/Microservice-2/blob/main/deploy.png)
![app running](https://github.com/Lhy121125/Microservice-2/blob/main/running.png)

# Microservice-2
Microservice 2 using Google App Engine

This will be our second microservice, and we will deploy it to Google App Engine
